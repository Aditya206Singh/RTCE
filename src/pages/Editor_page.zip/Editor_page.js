import React from 'react'

const Editor_page = () => {
  return (
    <div className="mainWrap">
      <div className="aside">
        <div className="asideInner">
          <div className="logo">
            <img className="logoImage" src="/code-sync.png" alt="logo"/>
          </div>
        </div>
      </div>
      <div className="editorWrap">Editor goes here</div>
      
    </div>
  );
}

export default Editor_page
